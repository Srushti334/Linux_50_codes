#!/bin/bash
arr=(24 27 84 11 99)
echo "Given array: ${arr[@]}"
len=${#arr[@]}
echo "The length of the array is: $len"

