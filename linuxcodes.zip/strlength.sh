#!/bin/bash

str="My name is Tom!"

len=${#str}

echo "The length of the string is: $len"

