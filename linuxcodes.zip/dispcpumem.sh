#!/bin/bash

echo "CPU and Memory Usage:"
top -b -n1 | head -n 10

