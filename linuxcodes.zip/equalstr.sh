#!/bin/bash

string1="hello"
string2="world"

if [ "$string1" == "$string2" ]; then
    echo "The strings are equal."
else
    echo "The strings are not equal."
fi

