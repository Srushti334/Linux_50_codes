#!/bin/bash
var1=10
var2=20
sum=$(($var1+$var2))


echo "The sum is:$sum"
